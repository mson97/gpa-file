# symbol-table
parsing E language and creating a symbol table of variables
