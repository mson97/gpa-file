package com.company;

public class e2j {

    public static void main(String args[]) {
        Scan scanner = new Scan();
        new Parser(scanner);
    }
}
