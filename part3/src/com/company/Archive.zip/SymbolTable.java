package com.company;

import java.util.HashSet;
import java.util.Stack;

public class SymbolTable {

    private Stack<HashSet<String>> table; // symbol table is stack (each scope) of hashsets of strings
    private int curr_scope;
    private int size; //new

    public SymbolTable() {
        table = new Stack<>();
        table.push(new HashSet<>());
        curr_scope = 0;
        size = 1; // new
    }

    public void exit_scope() {
        table.pop();
        size--;
        // curr_scope--;
    }

    public void enter_scope() {
        table.push(new HashSet<>());
        size++; //new
        //curr_scope++;
    }

    public void declare(Token id) {
        if (table.elementAt(curr_scope).contains(id.string)) {
            System.err.println("redeclaration of variable " + id.string);
        } else {
            table.elementAt(curr_scope).add(id.string);
        }
    }

    public void assign(Token id) {
        if (!table.elementAt(curr_scope).contains(id.string)) {
            System.out.println(id.string + " is an undeclared variable on line " + id.lineNumber);
            System.exit(1);
        }
    }

    public void assign(Token id, int scope) {
        if (!table.elementAt(scope).contains(id.string)) {
            System.out.println(id + " is an undeclared variable");
            System.exit(1);
        }
    }

    public boolean locate(Token id, int scope) {
        if (table.elementAt(scope).contains(id.string)) {
            return true;
        } else {
            System.out.println("Variable not found in current scope.");
            return false;
        }
    }

    public boolean find(Token id) {
        return _find(id, 0);
    }

    public boolean _find(Token id, int scope) {
        if (table.elementAt(scope).contains(id.string)) {
            return true;
        }
        else if (scope == size) {
            return false;
        }
        else {
            return _find(id, scope++);
        }
    }

}
